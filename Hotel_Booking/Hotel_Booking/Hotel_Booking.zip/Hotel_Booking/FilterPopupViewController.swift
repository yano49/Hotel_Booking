//
//  FilterPopupViewController.swift
//  Hotel_Booking
//
//  Created by SHIN MIN  on 27/09/2024.
//

import UIKit

class FilterPopupViewController: UIViewController, UITextFieldDelegate {
    // Outlets for UI components
    @IBOutlet weak var bangkokButton: CheckboxButton!
    @IBOutlet weak var pattayaButton: CheckboxButton!
    @IBOutlet weak var chaingMaiButton: CheckboxButton!
    @IBOutlet weak var krabiButton: CheckboxButton!
    @IBOutlet weak var KohSamuiButton: CheckboxButton!
    @IBOutlet weak var startDateTextField: UITextField!
    @IBOutlet weak var endDateTextField: UITextField!
    
    // Variables to store filter state
    var selectedLocations: [String] = []
    var startDate: String = ""
    var endDate: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        startDateTextField.delegate = self
        endDateTextField.delegate = self
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let updatedText = (textField.text as NSString?)?.replacingCharacters(in: range, with: string) ?? string
        
        let datePattern = "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/([0-9]{2})$"
        let datePredicate = NSPredicate(format: "SELF MATCHES %@", datePattern)
        
        let isValid = datePredicate.evaluate(with: updatedText)
        
        if isValid {
            if textField == startDateTextField {
                startDate = updatedText
            } else if textField == endDateTextField {
                endDate = updatedText
            }
        }
        
        return true // Allow the text change
    }
    
    // Dismiss the keyboard when done is pressed
    @objc func donePressed() {
        view.endEditing(true)
    }
    
    // Cancel button action
    @IBAction func cancelPopup(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func searchButtonTapped(_ sender: UIButton) {
        
        if isValidDate(startDate) && isValidDate(endDate) {
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let searchVC = storyboard.instantiateViewController(withIdentifier: "SearchPageViewController") as? SearchPageViewController {
                searchVC.selectedLocations = self.selectedLocations
                searchVC.startDate = self.startDate
                searchVC.endDate = self.endDate
                self.present(searchVC, animated: true, completion: nil)
            }
        }
    }
    
    func isValidDate(_ date: String) -> Bool {
        let datePattern = "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/([0-9]{2})$"
        let datePredicate = NSPredicate(format: "SELF MATCHES %@", datePattern)
        return datePredicate.evaluate(with: date)
    }
    

    @IBAction func locationButtonTapped(_ sender: CheckboxButton) {
        guard let locationName = sender.titleLabel?.text else { return }
        
        sender.isSelected.toggle()
        
        if sender.isSelected {
            selectedLocations.append(locationName)
        } else {
            selectedLocations.removeAll { $0 == locationName }
        }
    }
    
    class CheckboxButton: UIButton {
        override var isSelected: Bool {
            didSet {
                self.backgroundColor = isSelected ? .blue : .lightGray
                self.setTitle(isSelected ? "✓" : "", for: .normal)
            }
        }
    }
}
