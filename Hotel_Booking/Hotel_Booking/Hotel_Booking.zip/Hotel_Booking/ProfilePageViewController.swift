//
//  ProfilePageViewController.swift
//  Hotel_Booking
//
//  Created by SHIN MIN  on 26/09/2024.
//

import UIKit

class ProfilePageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
